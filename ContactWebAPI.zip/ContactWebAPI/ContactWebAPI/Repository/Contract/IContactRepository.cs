﻿using ContactWebAPI.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ContactWebAPI.Repository.Contract
{
    public interface IContactRepository<T>
    {
        IEnumerable<Contact> GetAllContacts();

        Contact Save(Contact contact, string State);

        Contact GetContact(string criteria);
        int DeleteContact(string criteria);
    }
}
