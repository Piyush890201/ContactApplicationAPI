﻿using ContactWebAPI.Data;
using ContactWebAPI.Entities;
using ContactWebAPI.Repository.Contract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ContactWebAPI.Repository.Implementation
{
    public class ContactRepository:IContactRepository<Contact>
    {
        readonly ContactDbContext _context;
        public ContactRepository(ContactDbContext context)
        {
            _context = context;
        }

        public IEnumerable<Contact> GetAllContacts()
        {
            return _context.Contacts.ToList();
        }        

        public Contact GetContact(string criteria)
        {
            try
            {
                return _context.Contacts.Where(e => e.ContactNumber.Equals(criteria) || e.FirstName.Equals(criteria) || e.Email.Equals(criteria)).FirstOrDefault();
            }
            catch (Exception ex)
            {
                Logger.Debug(ex.Message);
                return null;
            }
        }     

        public Contact Save(Contact contact,string State)
        {
            try
            {
                if (_context != null)
                {
                    if(!string.IsNullOrEmpty(State) && !string.IsNullOrWhiteSpace(State))
                    {
                        if(State.Equals("Add"))
                        {
                            _context.Add(contact);
                        }
                        else if(State.Equals("Update"))
                        {
                            _context.Update(contact);
                        }
                        _context.SaveChanges();
                        return contact;
                    }
                    else
                    {
                        return null;
                    } 
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                Logger.Debug(ex.Message);
                return null;
            }
        }

        public int DeleteContact(string criteria)
        {
            int iRet = 0;
            try
            {
                if(_context != null)
                {
                    Contact contact = GetContact(criteria);
                    if(contact != null)
                    {
                        _context.Remove(contact);
                        iRet = 1;
                    }                    
                }                
            }
            catch (Exception ex)
            {
                Logger.Debug(ex.Message);
            }
            return iRet;
        }
    }
}
