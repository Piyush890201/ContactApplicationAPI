﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ContactWebAPI.Entities;
using ContactWebAPI.Repository.Contract;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ContactWebAPI.Controllers
{
    [Route("api/Contact")]
    [ApiController]
    public class ContactController : ControllerBase
    {
        private readonly IContactRepository<Contact> _contactRepository;

        public ContactController(IContactRepository<Contact> contactRepository)
        {
            _contactRepository = contactRepository;
        }

        [HttpGet]
        [Route("GetAllContacts")]
        public IActionResult GetAllContacts()
        {
            try
            {
                IEnumerable<Contact> contacts = _contactRepository.GetAllContacts();
                return Ok(contacts);
            }
            catch (Exception ex)
            {
                Logger.Debug(ex.Message);
                return StatusCode(500);
            }          
        }

        [HttpPost]
        [Route("AddContact")]
        public IActionResult AddContact([FromBody] Contact contactparam)
        {
            try
            {
                if(ModelState.IsValid)
                {
                    Contact contact = _contactRepository.Save(contactparam,"Add");
                    return Ok(contact);
                }
                else
                {
                    return BadRequest();
                }
            }
            catch (Exception ex)
            {
                Logger.Debug(ex.Message);
                return BadRequest();
            }
        }

        [HttpGet]
        [Route("GetContact")]
        public IActionResult GetContact(string criteria)
        {
            try
            {
                Contact contact = _contactRepository.GetContact(criteria);
                return Ok(contact);
            }
            catch (Exception ex)
            {
                Logger.Debug(ex.Message);
                return BadRequest();           
            }
        }

        [HttpPost]
        [Route("UpdateContact")]
        public IActionResult UpdateContact([FromBody] Contact contactparam)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    Contact contact = _contactRepository.Save(contactparam, "Update");
                    return Ok(contact);
                }
                else
                {
                    return BadRequest();
                }
            }
            catch (Exception ex)
            {
                Logger.Debug(ex.Message);
                return BadRequest();
            }
        }

        [HttpDelete]
        [Route("DeleteContact")]
        public IActionResult DeleteContact(string criteria)
        {
            try
            {
                if(!string.IsNullOrEmpty(criteria) && !string.IsNullOrWhiteSpace(criteria))
                {
                    int result = _contactRepository.DeleteContact(criteria);
                    return Ok(result);
                }
                else
                {
                    return Ok();
                }
               
            }
            catch (Exception ex)
            {
                Logger.Debug(ex.Message);
                return BadRequest();
            }
        }
    }
}